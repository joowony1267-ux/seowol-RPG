<?php
declare(strict_types=1);
namespace JobTree;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\utils\Config;
use pocketmine\item\VanillaItems;
use pocketmine\form\Form;

final class Main extends PluginBase{
    private array $jobs = [];
    private Config $data;

    public function onEnable() : void{
        @mkdir($this->getDataFolder());
        $this->saveResource("jobs.json");
        $json = json_decode(file_get_contents($this->getDataFolder() . "jobs.json"), true);
        $this->jobs = $json["categories"] ?? [];
        $this->data = new Config($this->getDataFolder() . "players.json", Config::JSON, []);
    }

    public function onDisable() : void{
        $this->data->save();
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool{
        if(!$sender instanceof Player){
            $sender->sendMessage("인게임에서만 사용 가능합니다.");
            return true;
        }
        $this->open($sender, $args[0] ?? "knight");
        return true;
    }

    private function pdata(Player $p) : array{
        return $this->data->get(strtolower($p->getName()), ["category" => null, "selected" => []]);
    }

    private function setPdata(Player $p, array $d) : void{
        $this->data->set(strtolower($p->getName()), $d);
        $this->data->save();
    }

    public function open(Player $p, string $category) : void{
        if(!isset($this->jobs[$category])){
            $category = array_key_first($this->jobs) ?? "knight";
        }
        $pdata = $this->pdata($p);
        $buttons = [];
        $map = [];

        foreach($this->jobs as $cid => $cat){
            $lock = ($pdata["category"] !== null && $pdata["category"] !== $cid) ? " §c✕" : "";
            $first = $cat["nodes"][0][0] ?? "background";
            $buttons[] = [
                "text" => "§l" . ($cat["name"] ?? $cid) . $lock . "\n§7카테고리 보기",
                "image" => ["type" => "path", "data" => "textures/job/" . $cid . "/" . $first]
            ];
            $map[] = ["type" => "category", "category" => $cid];
        }

        foreach(($this->jobs[$category]["nodes"] ?? []) as $raw){
            [$id,$name,$feature,$texture,$stage,$parent] = array_pad($raw, 6, "");
            $node = ["id"=>$id,"name"=>$name,"feature"=>$feature,"texture"=>$texture,"stage"=>(int)$stage,"parent"=>$parent];
            $state = $this->state($pdata, $category, $node);
            $prefix = $state === "selected" ? "§a✓ " : ($state === "locked" ? "§c✕ " : "§e");
            $buttons[] = [
                "text" => $prefix . "§l{$name}\n§7{$feature}\n§b조건: 다이아몬드 1개",
                "image" => ["type" => "path", "data" => $texture]
            ];
            $map[] = ["type" => "node", "category" => $category, "id" => $id];
        }

        $p->sendForm(new class($this, $category, $buttons, $map) implements Form{
            public function __construct(private Main $plugin, private string $category, private array $buttons, private array $map){}
            public function jsonSerialize() : array{
                return [
                    "type" => "form",
                    "title" => "§y§r직업트리 : " . $this->plugin->getCategoryName($this->category),
                    "content" => "",
                    "buttons" => $this->buttons
                ];
            }
            public function handleResponse(Player $player, $data) : void{
                if($data === null || !isset($this->map[$data])) return;
                $m = $this->map[$data];
                if($m["type"] === "category"){
                    $this->plugin->open($player, $m["category"]);
                    return;
                }
                $this->plugin->select($player, $m["category"], $m["id"]);
            }
        });
    }

    public function getCategoryName(string $category) : string{
        return (string)($this->jobs[$category]["name"] ?? $category);
    }

    private function findNode(string $category, string $id) : ?array{
        foreach(($this->jobs[$category]["nodes"] ?? []) as $raw){
            [$nid,$name,$feature,$texture,$stage,$parent] = array_pad($raw, 6, "");
            if($nid === $id){
                return ["id"=>$nid,"name"=>$name,"feature"=>$feature,"texture"=>$texture,"stage"=>(int)$stage,"parent"=>$parent];
            }
        }
        return null;
    }

    private function selectedAtStage(array $pdata, string $category, int $stage) : ?string{
        foreach(($pdata["selected"] ?? []) as $sid){
            $n = $this->findNode($category, (string)$sid);
            if($n !== null && $n["stage"] === $stage) return (string)$sid;
        }
        return null;
    }

    private function state(array $pdata, string $category, array $node) : string{
        if(in_array($node["id"], $pdata["selected"] ?? [], true)) return "selected";
        if($pdata["category"] !== null && $pdata["category"] !== $category) return "locked";
        if($this->selectedAtStage($pdata, $category, (int)$node["stage"]) !== null) return "locked";
        if((int)$node["stage"] > 1 && !in_array($node["parent"], $pdata["selected"] ?? [], true)) return "locked";
        return "available";
    }

    public function select(Player $p, string $category, string $id) : void{
        $node = $this->findNode($category, $id);
        if($node === null){
            $p->sendMessage("§c직업 정보를 찾을 수 없습니다.");
            return;
        }
        $pdata = $this->pdata($p);
        $state = $this->state($pdata, $category, $node);
        if($state === "selected"){
            $p->sendMessage("§a이미 선택한 직업입니다.");
            $this->open($p, $category);
            return;
        }
        if($state === "locked"){
            $p->sendMessage("§c아직 선택할 수 없습니다.");
            $this->open($p, $category);
            return;
        }
        $diamond = VanillaItems::DIAMOND()->setCount(1);
        if(!$p->getInventory()->contains($diamond)){
            $p->sendMessage("§c다이아몬드 1개가 필요합니다.");
            $this->open($p, $category);
            return;
        }
        $p->getInventory()->removeItem($diamond);
        if($pdata["category"] === null) $pdata["category"] = $category;
        $pdata["selected"][] = $id;
        $pdata["selected"] = array_values(array_unique($pdata["selected"]));
        $this->setPdata($p, $pdata);
        $p->sendMessage("§a전직 완료: §f" . $node["name"]);
        $this->open($p, $category);
    }
}
