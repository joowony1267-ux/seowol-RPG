<?php

namespace ReloadRes;

use pocketmine\plugin\PluginBase;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\resourcepacks\ResourcePackManager;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use ReflectionClass;

class Main extends PluginBase implements Listener {

    protected function onEnable() : void {
        $this->saveDefaultConfig();
        // 플레이어 접속 감지를 위해 이벤트 리스너 등록
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
        $this->getLogger()->info("§aReloadRes 플러그인 활성화 완료");
    }

    // 💡 테스트용: 플레이어가 접속하면 메시지를 보냄
    public function onPlayerJoin(PlayerJoinEvent $event) : void {
        $player = $event->getPlayer();
        $player->sendMessage("hellowow world"); // 이 글자를 다른 걸로 수정하고 리로드 해봐!
    }

    public function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool {
        if (!$sender->hasPermission("reloadres.cmd")) {
            $sender->sendMessage("§c권한이 없습니다.");
            return true;
        }

        $server = Server::getInstance();
        $console = new ConsoleCommandSender($server, $server->getLanguage());

        // 1. 일반 /reload (플러그인만 리로드)
        if ($command->getName() === "reload") {
            $sender->sendMessage("§e[시스템] 플러그인 리로드를 시작합니다...");
            $server->dispatchCommand($console, "pocketmine:reload");
            $sender->sendMessage("§a[완료] 플러그인이 성공적으로 리로드되었습니다.");
            return true;
        }

        // 2. /reloadres (리소스팩 강제 리로드 + 플러그인 리로드 + 자동 재접속)
        if ($command->getName() === "reloadres") {
            $server->broadcastMessage("§e[시스템] 서버 데이터 업데이트 중... 화면이 깜빡일 수 있습니다.");

            try {
                // 새로운 리소스팩 매니저 데이터를 폴더에서 읽어오기
                $newPackManager = new ResourcePackManager($server->getDataPath() . "resource_packs/", $server->getLogger());
                
                $reflection = new ReflectionClass($server);
                $found = false;
                
                // 엔진 내부의 모든 변수를 순회하며 ResourcePackManager 객체를 찾아냄 (이름이 달라도 찾음)
                foreach ($reflection->getProperties() as $property) {
                    $property->setAccessible(true);
                    if ($property->getValue($server) instanceof ResourcePackManager) {
                        $property->setValue($server, $newPackManager); // 발견하면 새 걸로 덮어씌움
                        $found = true;
                        break;
                    }
                }

                if (!$found) {
                    throw new \Exception("리소스팩 매니저 변수를 찾을 수 없습니다. (PMMP 버전 호환 불가)");
                }

                $sender->sendMessage("§a[시스템] 리소스팩 데이터를 성공적으로 다시 읽어들였습니다.");
            } catch (\Exception $e) {
                $sender->sendMessage("§c[오류] 리소스팩 리로드 중 문제가 발생했습니다: " . $e->getMessage());
                return true;
            }

            // 플러그인 리로드
            $server->dispatchCommand($console, "pocketmine:reload");

            $ip = $this->getConfig()->get("server-ip", "127.0.0.1");
            $port = $server->getPort();

            // 모든 플레이어 재접속 처리
            foreach ($server->getOnlinePlayers() as $player) {
                $player->transfer($ip, $port);
            }
            return true;
        }
        return false;
    }
}