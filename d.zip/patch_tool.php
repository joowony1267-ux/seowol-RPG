<?php
// 패치할 파일 후보들 (서버마다 경로가 다를 수 있음)
$targets = [
    __DIR__ . "/vendor/pocketmine/pocketmine-mp/src/Server.php",
    __DIR__ . "/src/pocketmine/Server.php"
];

$serverFile = null;
foreach($targets as $t){
    if(file_exists($t)){
        $serverFile = $t;
        break;
    }
}

if(!$serverFile){
    die("[오류] Server.php 파일을 찾을 수 없습니다. (Phar 파일만 사용 중이라면 패치가 불가능합니다. 소스 코드를 설치해주세요.)\n");
}

$contents = file_get_contents($serverFile);

if(strpos($contents, 'function reloadResourcePacks') !== false){
    die("[안내] 이미 패치가 적용되어 있습니다.\n");
}

$patchCode = "
    public function reloadResourcePacks() : void {
        \$this->resourcePackManager = new \\pocketmine\\resourcepacks\\ResourcePackManager(
            \$this->dataPath . \"resource_packs/\",
            \$this->logger
        );
        \$this->logger->info(\"§a[시스템] 리소스팩을 다시 로드했습니다.\");
    }
";

// 주입 위치 선정
$search = "public function getResourcePackManager()";
if(strpos($contents, $search) === false) die("[오류] 코드 주입 위치를 찾지 못했습니다.\n");

$newContents = str_replace($search, $patchCode . "\n\n\t" . $search, $contents);
file_put_contents($serverFile, $newContents);

echo "[성공] 코어 패치가 완료되었습니다!\n";